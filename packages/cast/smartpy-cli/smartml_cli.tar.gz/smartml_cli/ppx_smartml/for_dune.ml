(* Copyright 2019-2021 Smart Chain Arena LLC. *)

let () = Ppx_smartml_lib.Transformer.register_via_ppxlib ()
